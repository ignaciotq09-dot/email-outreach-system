# VELOCITY - Complete Landing Page Code

## Project Overview
A high-converting landing page for an AI-powered Gmail email outreach system with vibrant gradients, animations, and modern SaaS design.

## Tech Stack
- **React** with TypeScript
- **Tailwind CSS v4.0**
- **Motion (Framer Motion)** for animations
- **Shadcn/ui** components
- **Lucide React** for icons

---

## File Structure

```
/
├── App.tsx                          # Main app entry point
├── styles/
│   └── globals.css                  # Global styles and design tokens
├── components/
│   ├── Navigation.tsx               # Header navigation
│   ├── FuturisticHero.tsx          # Hero section with stats
│   ├── LogoCloud.tsx                # Company logos
│   ├── BentoFeatures.tsx            # Feature cards grid
│   ├── AIBrainVisualization.tsx     # AI animation canvas
│   ├── Floating3DEmailCards.tsx     # 3D email cards
│   ├── HowItWorksSection.tsx        # Process steps
│   ├── BeforeAfterSlider.tsx        # Before/After comparison
│   ├── EmailPreviewCarousel.tsx     # Email examples carousel
│   ├── ROICalculator.tsx            # Interactive calculator
│   ├── SocialProofSection.tsx       # Testimonials
│   ├── ComparisonTable.tsx          # Competitor comparison
│   ├── PricingSection.tsx           # Pricing plans
│   ├── SecurityBadges.tsx           # Trust badges
│   ├── FAQSection.tsx               # FAQ accordion
│   ├── CTASection.tsx               # Final call-to-action
│   ├── Footer.tsx                   # Footer links
│   ├── StickyCtaBar.tsx             # Sticky bottom bar
│   ├── LiveActivityFeed.tsx         # Live activity notifications
│   └── ExitIntentPopup.tsx          # Exit intent modal
│   └── ui/                          # Shadcn components
│       ├── button.tsx
│       ├── dialog.tsx
│       ├── accordion.tsx
│       └── ... (other ui components)
```

---

## Package Dependencies

```json
{
  "dependencies": {
    "react": "^18.0.0",
    "motion": "latest",
    "lucide-react": "latest",
    "react-slick": "latest",
    "slick-carousel": "latest",
    "recharts": "latest"
  }
}
```

**Import syntax notes:**
- Motion: `import { motion } from 'motion/react'`
- Standard imports: `import { Component } from 'package'`

---

## Complete Code Files

### `/App.tsx`
```tsx
import { Navigation } from "./components/Navigation";
import { FuturisticHero } from "./components/FuturisticHero";
import { LogoCloud } from "./components/LogoCloud";
import { BentoFeatures } from "./components/BentoFeatures";
import { Floating3DEmailCards } from "./components/Floating3DEmailCards";
import { HowItWorksSection } from "./components/HowItWorksSection";
import { AIBrainVisualization } from "./components/AIBrainVisualization";
import { BeforeAfterSlider } from "./components/BeforeAfterSlider";
import { EmailPreviewCarousel } from "./components/EmailPreviewCarousel";
import { ROICalculator } from "./components/ROICalculator";
import { SocialProofSection } from "./components/SocialProofSection";
import { ComparisonTable } from "./components/ComparisonTable";
import { PricingSection } from "./components/PricingSection";
import { SecurityBadges } from "./components/SecurityBadges";
import { FAQSection } from "./components/FAQSection";
import { CTASection } from "./components/CTASection";
import { Footer } from "./components/Footer";
import { StickyCtaBar } from "./components/StickyCtaBar";
import { LiveActivityFeed } from "./components/LiveActivityFeed";
import { ExitIntentPopup } from "./components/ExitIntentPopup";
import { Toaster } from "./components/ui/sonner";

export default function App() {
  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <Navigation />
      <FuturisticHero />
      <LogoCloud />
      <BentoFeatures />
      <AIBrainVisualization />
      <Floating3DEmailCards />
      <HowItWorksSection />
      <BeforeAfterSlider />
      <EmailPreviewCarousel />
      <ROICalculator />
      <SocialProofSection />
      <ComparisonTable />
      <PricingSection />
      <SecurityBadges />
      <FAQSection />
      <CTASection />
      <Footer />
      <StickyCtaBar />
      <LiveActivityFeed />
      <ExitIntentPopup />
      <Toaster />
    </div>
  );
}
```

---

### `/components/Navigation.tsx`
```tsx
import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { ChevronDown, Menu, X } from 'lucide-react';
import { motion } from 'motion/react';

export function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 100, damping: 20 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-lg border-b border-slate-200 shadow-sm'
          : 'bg-white border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <motion.div 
            className="flex-shrink-0"
            whileHover={{ scale: 1.02 }}
          >
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">V</span>
              </div>
              <span className="font-bold text-lg text-slate-900">
                VELOCITY
              </span>
            </div>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollToSection('features')}
              className="text-slate-600 hover:text-slate-900 transition-colors"
            >
              Features
            </button>
            <button
              onClick={() => scrollToSection('how-it-works')}
              className="text-slate-600 hover:text-slate-900 transition-colors"
            >
              How It Works
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="text-slate-600 hover:text-slate-900 transition-colors"
            >
              Pricing
            </button>
            <button
              onClick={() => scrollToSection('faq')}
              className="text-slate-600 hover:text-slate-900 transition-colors"
            >
              FAQ
            </button>
          </div>

          {/* Desktop CTAs */}
          <div className="hidden md:flex items-center gap-4">
            <Button
              variant="ghost"
              onClick={() => window.location.href = '/app'}
              className="text-slate-600 hover:text-slate-900"
            >
              Sign In
            </Button>
            <Button
              onClick={() => window.location.href = '/app'}
              className="bg-sky-600 hover:bg-sky-700 text-white shadow-sm"
            >
              Get Started
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-600 hover:text-slate-900"
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden border-t border-slate-200 bg-white"
        >
          <div className="px-4 py-4 space-y-3">
            <button
              onClick={() => scrollToSection('features')}
              className="block w-full text-left py-2 text-slate-600 hover:text-slate-900"
            >
              Features
            </button>
            <button
              onClick={() => scrollToSection('how-it-works')}
              className="block w-full text-left py-2 text-slate-600 hover:text-slate-900"
            >
              How It Works
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="block w-full text-left py-2 text-slate-600 hover:text-slate-900"
            >
              Pricing
            </button>
            <button
              onClick={() => scrollToSection('faq')}
              className="block w-full text-left py-2 text-slate-600 hover:text-slate-900"
            >
              FAQ
            </button>
            <div className="pt-4 space-y-2 border-t border-slate-200">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => window.location.href = '/app'}
              >
                Sign In
              </Button>
              <Button
                className="w-full bg-sky-600 hover:bg-sky-700"
                onClick={() => window.location.href = '/app'}
              >
                Get Started
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}
```

---

### `/components/FuturisticHero.tsx`
```tsx
import { useState } from 'react';
import { Button } from './ui/button';
import { Play, CheckCircle2, ArrowRight } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from './ui/dialog';
import { motion } from 'motion/react';

export function FuturisticHero() {
  const [showVideo, setShowVideo] = useState(false);

  return (
    <>
      <section className="relative pt-32 pb-24 px-4 overflow-hidden bg-gradient-to-br from-slate-50 via-white to-sky-50">
        {/* Bold decorative elements */}
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gradient-to-br from-sky-400/20 to-blue-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-violet-400/20 to-purple-500/20 rounded-full blur-3xl" />
        
        {/* Animated gradient orbs */}
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ 
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/4 right-1/4 w-96 h-96 bg-gradient-to-br from-pink-400/30 to-rose-500/30 rounded-full blur-3xl"
        />

        <div className="max-w-6xl mx-auto text-center relative z-10">
          {/* Badge with gradient */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8 bg-gradient-to-r from-sky-500 to-blue-600 shadow-lg shadow-sky-500/30"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
            </span>
            <span className="text-sm text-white font-medium">
              Join <strong>2,847+</strong> teams
            </span>
          </motion.div>

          {/* Main Title with gradient */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-6xl md:text-7xl lg:text-8xl mb-8 leading-[0.95] tracking-tight"
          >
            <span className="block text-slate-900">
              Turn Cold Emails
            </span>
            <span className="block bg-gradient-to-r from-sky-600 via-blue-600 to-violet-600 bg-clip-text text-transparent">
              Into Warm Deals
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl md:text-2xl mb-12 max-w-3xl mx-auto text-slate-600"
          >
            Send <span className="text-sky-600 font-semibold">100% personalized</span> emails at scale with AI
          </motion.p>

          {/* CTAs with gradient */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center mb-20"
          >
            <Button
              onClick={() => window.location.href = '/app'}
              size="lg"
              className="group px-8 py-6 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white shadow-xl shadow-sky-500/30 transition-all"
            >
              <span className="flex items-center gap-2">
                Start Free Trial
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </span>
            </Button>
            
            <Button
              onClick={() => setShowVideo(true)}
              size="lg"
              variant="outline"
              className="group px-8 py-6 border-2 border-slate-300 hover:border-sky-600 hover:bg-sky-50 transition-all"
            >
              <span className="flex items-center gap-2">
                <Play className="w-5 h-5 text-sky-600" />
                Watch Demo
              </span>
            </Button>
          </motion.div>

          {/* Stats with colorful cards */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto"
          >
            {[
              { value: '3.2M+', label: 'Emails Sent', gradient: 'from-sky-500 to-blue-600', icon: '📧' },
              { value: '847K+', label: 'Replies', gradient: 'from-violet-500 to-purple-600', icon: '💬' },
              { value: '92K+', label: 'Meetings', gradient: 'from-emerald-500 to-teal-600', icon: '📅' },
            ].map((stat, index) => (
              <motion.div 
                key={index}
                whileHover={{ scale: 1.05, y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
                className={`p-6 rounded-2xl bg-gradient-to-br ${stat.gradient} shadow-lg`}
              >
                <div className="text-4xl mb-2">{stat.icon}</div>
                <div className="text-4xl md:text-5xl mb-1 text-white">
                  {stat.value}
                </div>
                <div className="text-sm text-white/90">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Video Modal */}
      <Dialog open={showVideo} onOpenChange={setShowVideo}>
        <DialogContent className="max-w-4xl">
          <DialogTitle className="sr-only">Product Demo Video</DialogTitle>
          <DialogDescription className="sr-only">
            Watch a 2-minute demonstration of how our AI-powered email outreach system works
          </DialogDescription>
          <div className="aspect-video rounded-lg flex items-center justify-center bg-gradient-to-br from-sky-50 to-blue-50 border-2 border-sky-200">
            <div className="text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-sky-600 to-blue-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-sky-500/30">
                <Play className="w-10 h-10 text-white ml-1" />
              </div>
              <p className="text-lg text-slate-900 mb-1">2-Minute Product Demo</p>
              <p className="text-sm text-slate-600">
                Video player would be embedded here
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
```

---

### `/components/LogoCloud.tsx`
```tsx
import { motion } from 'motion/react';

const companies = [
  { name: 'Salesforce', width: '160' },
  { name: 'HubSpot', width: '140' },
  { name: 'Stripe', width: '120' },
  { name: 'Atlassian', width: '150' },
  { name: 'Zoom', width: '110' },
  { name: 'Slack', width: '120' },
];

export function LogoCloud() {
  return (
    <section className="py-16 px-4 bg-gradient-to-b from-white to-slate-50 border-b border-slate-100">
      <div className="max-w-7xl mx-auto">
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center text-xs uppercase tracking-widest text-slate-400 mb-8"
        >
          Trusted by teams at
        </motion.p>
        
        <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-6">
          {companies.map((company, index) => (
            <motion.div
              key={company.name}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 0.5, y: 0 }}
              whileHover={{ opacity: 1, scale: 1.1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-center justify-center"
            >
              <div
                className="text-slate-700 font-semibold transition-all cursor-pointer"
                style={{ width: company.width + 'px' }}
              >
                {company.name}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

---

### `/components/BentoFeatures.tsx`
```tsx
import { motion } from 'motion/react';
import { Sparkles, Zap, Target, BarChart3, Clock, Shield, Repeat, Users } from 'lucide-react';

const features = [
  {
    icon: Sparkles,
    title: 'AI Personalization',
    description: 'Every email uniquely crafted for maximum engagement',
    span: 'md:col-span-2',
    gradient: 'from-sky-500 to-blue-600',
    emoji: '✨',
  },
  {
    icon: Zap,
    title: 'Instant Reply Detection',
    description: 'Never miss a response',
    span: 'md:col-span-1',
    gradient: 'from-amber-500 to-orange-600',
    emoji: '⚡',
  },
  {
    icon: Target,
    title: 'Smart Targeting',
    description: 'Reach the right people at the right time',
    span: 'md:col-span-1',
    gradient: 'from-rose-500 to-pink-600',
    emoji: '🎯',
  },
  {
    icon: BarChart3,
    title: 'Real-time Analytics',
    description: 'Track performance with live dashboards and insights',
    span: 'md:col-span-2',
    gradient: 'from-emerald-500 to-teal-600',
    emoji: '📊',
  },
  {
    icon: Clock,
    title: 'Auto-Scheduling',
    description: 'Book meetings automatically',
    span: 'md:col-span-1',
    gradient: 'from-violet-500 to-purple-600',
    emoji: '⏰',
  },
  {
    icon: Shield,
    title: 'Enterprise Security',
    description: 'SOC 2 & GDPR compliant',
    span: 'md:col-span-1',
    gradient: 'from-blue-500 to-indigo-600',
    emoji: '🛡️',
  },
  {
    icon: Repeat,
    title: 'Smart Follow-ups',
    description: 'Automated sequences that feel human',
    span: 'md:col-span-1',
    gradient: 'from-fuchsia-500 to-purple-600',
    emoji: '🔄',
  },
  {
    icon: Users,
    title: 'Team Collaboration',
    description: 'Work together seamlessly with your entire team',
    span: 'md:col-span-2',
    gradient: 'from-teal-500 to-cyan-600',
    emoji: '👥',
  },
];

export function BentoFeatures() {
  return (
    <section id="features" className="py-20 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 bg-sky-50 text-sky-700 border border-sky-100">
            <Zap className="w-4 h-4" />
            <span className="font-medium">Powerful Features</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4 text-slate-900">
            Everything You Need To
            <br />
            <span className="bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">
              Close More Deals
            </span>
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Powerful AI-driven tools designed to help you connect with prospects and convert leads faster
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className={`${feature.span} group`}
              >
                <motion.div 
                  whileHover={{ y: -8, scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 300 }}
                  className={`h-full p-8 rounded-2xl bg-gradient-to-br ${feature.gradient} shadow-lg hover:shadow-2xl transition-all relative overflow-hidden`}
                >
                  {/* Decorative gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  
                  <div className="relative z-10">
                    <div className="text-5xl mb-4">{feature.emoji}</div>
                    <h3 className="text-2xl mb-3 text-white">
                      {feature.title}
                    </h3>
                    <p className="text-white/90 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </motion.div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
```

---

### `/components/PricingSection.tsx`
```tsx
import { useState } from 'react';
import { Button } from './ui/button';
import { Check, Zap, Rocket, Crown } from 'lucide-react';
import { motion } from 'motion/react';

export function PricingSection() {
  const [isAnnual, setIsAnnual] = useState(false);

  const plans = [
    {
      name: 'Free',
      icon: Zap,
      price: 0,
      features: [
        '50 emails/month',
        'Basic personalization',
        'Reply detection',
        'Email support',
      ],
      cta: 'Start Free',
      popular: false,
      gradient: 'from-slate-600 to-slate-700',
    },
    {
      name: 'Pro',
      icon: Rocket,
      monthlyPrice: 49,
      annualPrice: 39,
      features: [
        '2,000 emails/month',
        'Advanced AI personalization',
        'All features included',
        'Priority support',
      ],
      cta: 'Start Building Campaigns',
      popular: true,
      gradient: 'from-sky-600 to-blue-700',
    },
    {
      name: 'Scale',
      icon: Crown,
      monthlyPrice: 149,
      annualPrice: 119,
      features: [
        'Unlimited emails',
        'Custom AI training',
        'Dedicated success manager',
        'API access',
      ],
      cta: 'Book a Demo',
      popular: false,
      gradient: 'from-violet-600 to-purple-700',
    },
  ];

  const getPrice = (plan: typeof plans[0]) => {
    if (plan.price !== undefined) return plan.price;
    return isAnnual ? plan.annualPrice : plan.monthlyPrice;
  };

  const handleCTA = (planName: string) => {
    if (planName === 'Scale') {
      window.open('https://calendly.com', '_blank');
    } else {
      window.location.href = '/app';
    }
  };

  return (
    <section id="pricing" className="py-20 px-4 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-2 rounded-full bg-sky-50 text-sky-700 border border-sky-100 mb-4">
            Flexible Pricing
          </div>
          <h2 className="text-4xl md:text-5xl text-slate-900 mb-4">Simple, Transparent Pricing</h2>
          <p className="text-lg text-slate-600 mb-8">
            Choose the perfect plan for your team
          </p>

          {/* Toggle */}
          <div className="inline-flex items-center gap-3 p-1 bg-white border border-slate-200 rounded-full">
            <button
              onClick={() => setIsAnnual(false)}
              className={`px-6 py-2 rounded-full transition-all ${
                !isAnnual
                  ? 'bg-sky-600 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setIsAnnual(true)}
              className={`px-6 py-2 rounded-full transition-all ${
                isAnnual
                  ? 'bg-sky-600 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Annual
              <span className="ml-2 text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">
                Save 20%
              </span>
            </button>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => {
            const Icon = plan.icon;
            const price = getPrice(plan);
            
            return (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`relative ${
                  plan.popular ? 'md:-mt-4 md:mb-0' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-sky-600 to-blue-600 text-white px-4 py-1 rounded-full text-sm shadow-lg">
                    ⭐ Most Popular
                  </div>
                )}
                
                <div
                  className={`h-full p-8 rounded-2xl bg-white border-2 ${
                    plan.popular
                      ? 'border-sky-600 shadow-xl'
                      : 'border-slate-200 hover:border-slate-300'
                  } transition-all`}
                >
                  <div className="mb-6">
                    <div className="w-10 h-10 rounded-lg bg-slate-900 flex items-center justify-center mb-4">
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-xl text-slate-900 mb-2 font-light">{plan.name}</h3>
                    <div className="flex items-baseline gap-1">
                      <span className="text-5xl text-slate-900 font-light">${price}</span>
                      {plan.price !== 0 && (
                        <span className="text-slate-500">
                          /{isAnnual ? 'mo' : 'month'}
                        </span>
                      )}
                    </div>
                    {isAnnual && plan.price !== 0 && (
                      <p className="text-sm text-slate-500 mt-1">
                        Billed annually
                      </p>
                    )}
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-sky-600 flex-shrink-0 mt-0.5" />
                        <span className="text-slate-600">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={() => handleCTA(plan.name)}
                    className={`w-full ${
                      plan.popular
                        ? 'bg-sky-600 hover:bg-sky-700 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-900'
                    }`}
                  >
                    {plan.cta}
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
```

---

### `/components/FAQSection.tsx`
```tsx
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import { motion } from 'motion/react';
import { HelpCircle } from 'lucide-react';

const faqs = [
  {
    question: 'How does the AI personalization work?',
    answer:
      'Our AI analyzes your writing style from sample emails and learns your tone, vocabulary, and messaging patterns. It then generates unique emails for each recipient based on their profile, company, and context—ensuring every message feels personally written.',
  },
  {
    question: 'Will emails be sent from my Gmail account?',
    answer:
      'Yes! The system connects directly to your Gmail account via secure OAuth. All emails are sent from your actual email address, maintaining your domain reputation and ensuring deliverability.',
  },
  {
    question: 'What happens if someone replies?',
    answer:
      'Our 4-layer reply detection system monitors responses across all threads and automatically stops any scheduled follow-ups. You receive instant notifications via email and SMS, and the AI can even book meetings directly to your calendar if requested.',
  },
  {
    question: 'Can I cancel anytime?',
    answer:
      'Absolutely. There are no contracts or commitments. You can upgrade, downgrade, or cancel your subscription at any time from your account settings. The free plan is available forever with no credit card required.',
  },
  {
    question: 'How accurate is the reply detection?',
    answer:
      'Our reply detection has a 99.7% accuracy rate. It monitors primary inbox, threaded replies, different email aliases, and even catches responses that come from forwarded emails or different domains within the same organization.',
  },
];

export function FAQSection() {
  return (
    <section id="faq" className="py-20 px-4 bg-white">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-2 rounded-full bg-sky-50 text-sky-700 border border-sky-100 mb-4">
            💡 FAQ
          </div>
          <h2 className="text-4xl md:text-5xl text-slate-900 mb-4">
            Questions? <span className="bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">Answered.</span>
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border-2 border-slate-200 rounded-xl px-6 bg-white hover:border-sky-300 hover:shadow-md transition-all"
              >
                <AccordionTrigger className="text-left hover:no-underline py-5">
                  <span className="text-slate-900">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="text-slate-600 pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-12 text-center p-8 bg-gradient-to-br from-sky-50 to-blue-50 rounded-2xl border-2 border-sky-200"
        >
          <div className="text-5xl mb-4">🤝</div>
          <p className="text-slate-900 mb-2">
            Still have questions?
          </p>
          <p className="text-slate-600 mb-6 text-sm">
            Can't find the answer you're looking for? Please chat to our friendly team.
          </p>
          <a
            href="mailto:support@velocity.com"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white rounded-lg transition-all shadow-lg shadow-sky-500/30"
          >
            Contact Support
          </a>
        </motion.div>
      </div>
    </section>
  );
}
```

---

### `/components/CTASection.tsx`
```tsx
import { Button } from './ui/button';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function CTASection() {
  return (
    <section className="py-24 px-4 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
      {/* Animated gradient orbs */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-sky-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl" />
      
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-block px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-6">
            <span className="text-white text-sm">🚀 Ready to Get Started?</span>
          </div>
          
          <h2 className="text-5xl md:text-6xl text-white mb-6">
            Ready to <span className="bg-gradient-to-r from-sky-400 to-blue-500 bg-clip-text text-transparent">close more deals?</span>
          </h2>

          <p className="text-xl text-slate-300 mb-10 max-w-2xl mx-auto">
            Start free, no credit card required
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button
              size="lg"
              className="bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white shadow-xl shadow-sky-500/30 transition-all group px-8"
              asChild
            >
              <a href="/app">
                Start Free Trial
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-white border-2 border-white/30 hover:bg-white/10 backdrop-blur-sm transition-all px-8"
              onClick={() => window.open('https://calendly.com', '_blank')}
            >
              Book a Demo
            </Button>
          </div>

          {/* Trust Indicators with icons */}
          <div className="flex flex-wrap items-center justify-center gap-8 text-slate-400 text-sm">
            <div className="flex items-center gap-2 bg-white/5 backdrop-blur-sm px-4 py-2 rounded-full border border-white/10">
              <svg className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
              <span className="text-white">4.8/5 Rating</span>
            </div>
            <div className="flex items-center gap-2 bg-white/5 backdrop-blur-sm px-4 py-2 rounded-full border border-white/10">
              <svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
              <span className="text-white">Bank-Level Security</span>
            </div>
            <div className="flex items-center gap-2 bg-white/5 backdrop-blur-sm px-4 py-2 rounded-full border border-white/10">
              <svg className="w-4 h-4 text-sky-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <span className="text-white">5-Minute Setup</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
```

---

### `/components/Footer.tsx`
```tsx
import { Github, Twitter, Linkedin, Mail } from 'lucide-react';

export function Footer() {
  const footerLinks = {
    product: [
      { label: 'Features', href: '#features' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'FAQ', href: '#faq' },
      { label: 'Integrations', href: '#' },
    ],
    company: [
      { label: 'About', href: '#' },
      { label: 'Blog', href: '#' },
      { label: 'Careers', href: '#' },
      { label: 'Contact', href: '#' },
    ],
    legal: [
      { label: 'Privacy', href: '#' },
      { label: 'Terms', href: '#' },
      { label: 'Security', href: '#' },
      { label: 'GDPR', href: '#' },
    ],
  };

  return (
    <footer className="bg-slate-900 text-slate-400">
      <div className="max-w-7xl mx-auto px-4">
        {/* Main Footer Content */}
        <div className="py-12 grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">V</span>
              </div>
              <span className="font-bold text-lg text-white">
                VELOCITY
              </span>
            </div>
            <p className="text-sm leading-relaxed mb-6">
              Email outreach that doesn't feel like outreach. Transform cold emails into warm conversations with AI.
            </p>
            
            {/* Social Links */}
            <div className="flex gap-3">
              {[
                { icon: Twitter, href: '#', label: 'Twitter' },
                { icon: Linkedin, href: '#', label: 'LinkedIn' },
                { icon: Github, href: '#', label: 'GitHub' },
                { icon: Mail, href: '#', label: 'Email' },
              ].map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="w-9 h-9 rounded-lg bg-slate-800 hover:bg-sky-600 flex items-center justify-center transition-all"
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Product */}
          <div>
            <h3 className="text-white font-semibold mb-4">Product</h3>
            <ul className="space-y-3 text-sm">
              {footerLinks.product.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="hover:text-sky-500 transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-white font-semibold mb-4">Company</h3>
            <ul className="space-y-3 text-sm">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="hover:text-sky-500 transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-white font-semibold mb-4">Legal</h3>
            <ul className="space-y-3 text-sm">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="hover:text-sky-500 transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800 py-6 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
          <p>
            © {new Date().getFullYear()} Velocity. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-sky-500 transition-colors">
              Status
            </a>
            <a href="#" className="hover:text-sky-500 transition-colors">
              Changelog
            </a>
            <a href="#" className="hover:text-sky-500 transition-colors">
              API Docs
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
```

---

## Additional Components

The app also includes these additional sections:

- **AIBrainVisualization** - Animated canvas visualization
- **Floating3DEmailCards** - 3D card showcase
- **HowItWorksSection** - Step-by-step process
- **BeforeAfterSlider** - Interactive before/after slider
- **EmailPreviewCarousel** - Email examples carousel
- **ROICalculator** - Interactive ROI calculator
- **SocialProofSection** - Customer testimonials
- **ComparisonTable** - Competitor comparison
- **SecurityBadges** - Security compliance badges
- **StickyCtaBar** - Sticky bottom CTA
- **LiveActivityFeed** - Live activity notifications
- **ExitIntentPopup** - Exit intent modal

All these components follow the same design system with:
- Vibrant gradients (sky, blue, violet, emerald, amber, rose, etc.)
- Motion animations with smooth transitions
- Emojis for visual interest
- Hover effects (scale, lift, glow)
- Consistent spacing and typography
- Glassmorphism effects in dark sections

---

## Design System

### Colors
- **Primary**: Sky Blue (#0EA5E9), Blue (#2563EB)
- **Secondary**: Violet (#8B5CF6), Purple (#A855F7)
- **Accent**: Emerald (#10B981), Amber (#F59E0B), Rose (#F43F5E)
- **Neutral**: Slate grays

### Typography
- **Font**: Inter (Google Fonts)
- **Weights**: 400 (normal), 500 (medium), 700 (bold), 900 (black)

### Animations
- **Motion library** for smooth transitions
- Spring physics for natural movement
- Scroll-triggered animations with `whileInView`
- Hover effects: scale, translate, shadow changes

### Components Pattern
All components use:
1. Motion wrapper for entrance animations
2. Gradient backgrounds with blur effects
3. Rounded corners (rounded-lg, rounded-xl, rounded-2xl)
4. Shadow depth (shadow-sm, shadow-lg, shadow-xl)
5. Responsive grid layouts
6. Hover interactions

---

## Key Features

✅ **Responsive Design** - Mobile, tablet, desktop optimized  
✅ **Smooth Scroll Navigation** - Anchor-based smooth scrolling  
✅ **Video Modal** - Dialog with embedded video placeholder  
✅ **Pricing Toggle** - Monthly/Annual switcher with discount  
✅ **FAQ Accordion** - Expandable Q&A  
✅ **Interactive Elements** - Calculators, sliders, carousels  
✅ **Gradient Animations** - Pulsing, scaling, rotating effects  
✅ **Exit Intent Popup** - Capture leaving visitors  
✅ **Live Activity Feed** - Real-time notification simulation  
✅ **Sticky CTA Bar** - Bottom conversion bar  

---

## Customization Guide

### Change Brand Colors
Edit `/styles/globals.css`:
```css
--electric-teal: #0EA5E9; /* Change to your brand color */
```

### Modify Content
All text content is in the component files. Search for strings to update copy.

### Add/Remove Sections
Edit `/App.tsx` and comment out or add components:
```tsx
<BentoFeatures /> {/* Remove this line to hide features */}
```

### Adjust Animations
Modify Motion props:
```tsx
<motion.div
  initial={{ opacity: 0, y: 20 }}     // Starting state
  animate={{ opacity: 1, y: 0 }}      // End state
  transition={{ duration: 0.6 }}       // Speed
>
```

---

## Deployment Notes

1. **Build for production**: All components are optimized for static export
2. **Images**: Currently using Unsplash placeholders - replace with real assets
3. **Links**: Update href="/app" to your actual signup URL
4. **Calendly**: Replace 'https://calendly.com' with your booking link
5. **Email**: Update 'support@velocity.com' with real support email

---

## Browser Support

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers

---

This is a complete, production-ready landing page with modern design patterns, smooth animations, and conversion-optimized layout! 🚀
