
  # AI-Powered Email Outreach Landing Page

  This is a code bundle for AI-Powered Email Outreach Landing Page. The original project is available at https://www.figma.com/design/5gmPZ8npTAUtU307y3tXkM/AI-Powered-Email-Outreach-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  