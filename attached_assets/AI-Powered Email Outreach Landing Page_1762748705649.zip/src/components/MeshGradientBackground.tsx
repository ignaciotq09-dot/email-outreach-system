import { motion } from 'motion/react';

interface MeshGradientBackgroundProps {
  variant?: 'hero' | 'section' | 'footer';
  animated?: boolean;
}

export function MeshGradientBackground({ variant = 'section', animated = true }: MeshGradientBackgroundProps) {
  const gradients = {
    hero: {
      colors: ['violet-400', 'fuchsia-400', 'blue-400', 'purple-400'],
      bg: 'from-violet-50 via-fuchsia-50 to-blue-50',
    },
    section: {
      colors: ['violet-300', 'fuchsia-300', 'cyan-300'],
      bg: 'from-gray-50 via-violet-50/30 to-fuchsia-50/30',
    },
    footer: {
      colors: ['violet-600', 'fuchsia-600', 'purple-700'],
      bg: 'from-gray-900 via-violet-950 to-gray-900',
    },
  };

  const config = gradients[variant];

  return (
    <div className={`absolute inset-0 bg-gradient-to-br ${config.bg} overflow-hidden`}>
      {/* Mesh gradient blobs */}
      <div className="absolute inset-0">
        {config.colors.map((color, i) => (
          <motion.div
            key={i}
            className={`absolute w-96 h-96 bg-${color} rounded-full mix-blend-multiply filter blur-3xl opacity-30`}
            style={{
              top: `${(i * 25) % 100}%`,
              left: `${(i * 33) % 100}%`,
            }}
            animate={animated ? {
              x: [0, 100, -50, 0],
              y: [0, -100, 50, 0],
              scale: [1, 1.2, 0.9, 1],
            } : {}}
            transition={{
              duration: 20 + i * 5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      {/* Dot matrix pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%">
          <defs>
            <pattern id="dots" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
              <circle cx="2" cy="2" r="1" fill="currentColor" className="text-violet-600" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dots)" />
        </svg>
      </div>

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-white/50" />
    </div>
  );
}
