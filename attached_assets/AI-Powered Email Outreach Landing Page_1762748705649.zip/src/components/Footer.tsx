import { Github, Twitter, Linkedin, Mail } from 'lucide-react';
import { AnimatedLogo } from './AnimatedLogo';
import { motion } from 'motion/react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-900 to-violet-900 text-gray-300 relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.03)_1px,transparent_1px)] bg-[size:64px_64px]"></div>
      <motion.div 
        className="absolute top-0 right-0 w-96 h-96 bg-violet-600/10 rounded-full filter blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.15, 0.1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        {/* Main Footer Content */}
        <div className="py-12 grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <AnimatedLogo size="default" />
              <span className="text-xl bg-gradient-to-r from-violet-400 via-fuchsia-400 to-violet-400 bg-clip-text text-transparent bg-[length:200%_auto] animate-[gradient-shift_3s_ease-in-out_infinite]">
                EmailAI
              </span>
            </div>
            <p className="text-sm text-gray-400 mb-6 leading-relaxed">
              Email outreach that doesn't feel like outreach. Transform cold emails into warm conversations with AI.
            </p>
            
            {/* Social Links */}
            <div className="flex gap-3">
              {[
                { icon: Twitter, href: '#' },
                { icon: Linkedin, href: '#' },
                { icon: Github, href: '#' },
                { icon: Mail, href: '#' },
              ].map((social, i) => {
                const Icon = social.icon;
                return (
                  <motion.a
                    key={i}
                    href={social.href}
                    className="w-9 h-9 rounded-lg bg-white/5 hover:bg-gradient-to-r hover:from-violet-600 hover:to-fuchsia-600 flex items-center justify-center transition-all duration-300 group relative overflow-hidden"
                    whileHover={{ scale: 1.15, rotate: 5 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Icon className="w-4 h-4 relative z-10" />
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-violet-600 to-fuchsia-600 opacity-0 group-hover:opacity-100"
                      initial={{ scale: 0 }}
                      whileHover={{ scale: 1 }}
                      transition={{ duration: 0.3 }}
                    />
                  </motion.a>
                );
              })}
            </div>
          </div>

          {/* Product */}
          <div>
            <h3 className="text-white mb-4">Product</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="#features" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Features
                </a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Pricing
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  API Documentation
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Status Page
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Changelog
                </a>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-white mb-4">Company</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Careers
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Press Kit
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Legal & Resources */}
          <div>
            <h3 className="text-white mb-4">Legal & Support</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Cookie Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-violet-400 transition-colors flex items-center gap-2 group">
                  <span className="w-0 h-px bg-gradient-to-r from-violet-400 to-fuchsia-400 group-hover:w-4 transition-all"></span>
                  GDPR
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-6 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-gray-400">
              © 2024 Email Outreach System. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-violet-400 transition-colors">
                Privacy Policy
              </a>
              <span className="text-gray-700">|</span>
              <a href="#" className="text-gray-400 hover:text-violet-400 transition-colors">
                Terms of Service
              </a>
              <span className="text-gray-700">|</span>
              <a href="#" className="text-gray-400 hover:text-violet-400 transition-colors">
                API Documentation
              </a>
              <span className="text-gray-700">|</span>
              <a href="#" className="text-gray-400 hover:text-violet-400 transition-colors">
                Status Page
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
