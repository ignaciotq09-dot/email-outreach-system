import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Check, Zap, Rocket, Crown } from 'lucide-react';
import { motion } from 'motion/react';
import { TiltCard } from './TiltCard';
import { MagneticButton } from './MagneticButton';

export function PricingSection() {
  const [isAnnual, setIsAnnual] = useState(false);

  const plans = [
    {
      name: 'Free',
      icon: Zap,
      price: 0,
      features: [
        '50 emails/month',
        'Basic personalization',
        'Reply detection',
        'Email support',
      ],
      cta: 'Start Free',
      popular: false,
      gradient: 'from-gray-500 to-gray-600',
      bg: 'from-gray-50 to-gray-100',
    },
    {
      name: 'Pro',
      icon: Rocket,
      monthlyPrice: 49,
      annualPrice: 39,
      features: [
        '2,000 emails/month',
        'Advanced AI personalization',
        'All features included',
        'Priority support',
      ],
      cta: 'Start Building Campaigns',
      popular: true,
      gradient: 'from-violet-500 to-fuchsia-600',
      bg: 'from-violet-50 to-fuchsia-50',
    },
    {
      name: 'Scale',
      icon: Crown,
      monthlyPrice: 149,
      annualPrice: 119,
      features: [
        'Unlimited emails',
        'Custom AI training',
        'Dedicated success manager',
        'API access',
      ],
      cta: 'Book a Demo',
      popular: false,
      gradient: 'from-blue-500 to-cyan-600',
      bg: 'from-blue-50 to-cyan-50',
    },
  ];

  const getPrice = (plan: typeof plans[0]) => {
    if (plan.price !== undefined) return plan.price;
    return isAnnual ? plan.annualPrice : plan.monthlyPrice;
  };

  const handleCTA = (planName: string) => {
    if (planName === 'Scale') {
      window.open('https://calendly.com', '_blank');
    } else {
      window.location.href = '/app';
    }
  };

  const scrollToPricing = () => {
    const element = document.getElementById('pricing');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="pricing" className="py-24 px-4 bg-gradient-to-br from-gray-50 via-white to-violet-50/30 relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-violet-200 rounded-full filter blur-3xl opacity-20"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-fuchsia-200 rounded-full filter blur-3xl opacity-20"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <div className="inline-block px-4 py-1 rounded-full bg-gradient-to-r from-violet-100 to-fuchsia-100 text-violet-700 mb-4">
            Flexible Pricing
          </div>
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-4">Simple, Transparent Pricing</h2>
          <p className="text-xl text-gray-600 mb-8">
            Start free. Upgrade when you're ready.
          </p>

          {/* Pricing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <span className={!isAnnual ? 'text-gray-900' : 'text-gray-500'}>
              Monthly
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className={`relative w-16 h-8 rounded-full transition-all duration-300 ${
                isAnnual 
                  ? 'bg-gradient-to-r from-violet-500 to-fuchsia-600 shadow-lg shadow-violet-500/50' 
                  : 'bg-gray-300'
              }`}
            >
              <motion.div
                className="absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md"
                animate={{ x: isAnnual ? 32 : 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            </button>
            <span className={isAnnual ? 'text-gray-900' : 'text-gray-500'}>
              Annual
              <span className="ml-2 text-sm px-2 py-1 rounded-full bg-gradient-to-r from-green-100 to-emerald-100 text-green-700">
                Save 20%
              </span>
            </span>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">
          {plans.map((plan, index) => {
            const Icon = plan.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative h-full"
              >
                <TiltCard className="h-full">
                  <Card
                    className={`relative group border-0 shadow-xl hover:shadow-2xl transition-all duration-300 h-full overflow-hidden ${
                      plan.popular ? 'scale-105 md:scale-110' : ''
                    }`}
                  >
                  {/* Gradient Background */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${plan.bg} opacity-50`}></div>
                  
                  {/* Popular Badge */}
                  {plan.popular && (
                    <div className={`absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r ${plan.gradient} text-white text-sm shadow-lg z-20`}>
                      Most Popular
                    </div>
                  )}

                  {/* Border Gradient */}
                  <div className={`absolute inset-0 bg-gradient-to-r ${plan.gradient} ${plan.popular ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'} transition-opacity duration-300 -z-10`}></div>
                  <div className="absolute inset-[2px] bg-white rounded-lg z-0"></div>
                  
                  {/* Shimmer effect on hover */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent opacity-0 group-hover:opacity-100 -z-10"
                    animate={{ x: ['-200%', '200%'] }}
                    transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 2 }}
                  />

                  <CardHeader className="relative z-10 pb-8">
                    {/* Icon */}
                    <div className="relative inline-block mb-4">
                      <div className={`absolute inset-0 bg-gradient-to-r ${plan.gradient} rounded-xl blur opacity-50`}></div>
                      <div className={`relative w-12 h-12 bg-gradient-to-r ${plan.gradient} rounded-xl flex items-center justify-center shadow-lg`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                    </div>

                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <div className="mt-4">
                      <span className="text-5xl text-gray-900">${getPrice(plan)}</span>
                      <span className="text-gray-600">/month</span>
                    </div>
                    {isAnnual && plan.monthlyPrice && (
                      <div className="text-sm text-gray-500 mt-1">
                        Billed ${getPrice(plan)! * 12}/year
                      </div>
                    )}
                  </CardHeader>

                  <CardContent className="relative z-10">
                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, fIndex) => (
                        <motion.li
                          key={fIndex}
                          initial={{ opacity: 0, x: -20 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: 0.3 + fIndex * 0.1 }}
                          className="flex items-start gap-3"
                        >
                          <div className={`w-5 h-5 rounded-full bg-gradient-to-r ${plan.gradient} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                            <Check className="w-3 h-3 text-white" strokeWidth={3} />
                          </div>
                          <span className="text-gray-700">{feature}</span>
                        </motion.li>
                      ))}
                    </ul>

                    <MagneticButton
                      className={`w-full relative overflow-hidden ${
                        plan.popular
                          ? `bg-gradient-to-r ${plan.gradient} hover:shadow-lg hover:shadow-violet-500/50 text-white`
                          : 'bg-white hover:bg-gray-50 border-2 border-gray-200'
                      } transition-all duration-300 px-6 py-3 rounded-lg`}
                      onClick={() => handleCTA(plan.name)}
                    >
                      <span className="relative z-10">{plan.cta}</span>
                      {plan.popular && (
                        <>
                          <div className={`absolute inset-0 bg-gradient-to-r from-fuchsia-600 to-violet-600 opacity-0 group-hover:opacity-100 transition-opacity`}></div>
                          <motion.div
                            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                            animate={{ x: ['-200%', '200%'] }}
                            transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                          />
                        </>
                      )}
                    </MagneticButton>
                  </CardContent>
                  </Card>
                </TiltCard>
              </motion.div>
            );
          })}
        </div>

        {/* Secondary CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="flex flex-wrap justify-center gap-4"
        >
          <Button
            variant="outline"
            size="lg"
            className="border-2 border-violet-200 hover:border-violet-400 hover:bg-violet-50"
            onClick={() => handleCTA('Scale')}
          >
            Book a Demo
          </Button>
          <Button
            variant="ghost"
            size="lg"
            className="hover:bg-violet-50 hover:text-violet-600"
            onClick={scrollToPricing}
          >
            View Pricing
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
