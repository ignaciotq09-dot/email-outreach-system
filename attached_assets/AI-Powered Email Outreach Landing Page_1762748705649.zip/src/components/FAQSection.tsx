import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import { motion } from 'motion/react';
import { HelpCircle } from 'lucide-react';

const faqs = [
  {
    question: 'How does the AI personalization work?',
    answer:
      'Our AI analyzes your writing style from sample emails and learns your tone, vocabulary, and messaging patterns. It then generates unique emails for each recipient based on their profile, company, and context—ensuring every message feels personally written.',
  },
  {
    question: 'Will emails be sent from my Gmail account?',
    answer:
      'Yes! The system connects directly to your Gmail account via secure OAuth. All emails are sent from your actual email address, maintaining your domain reputation and ensuring deliverability.',
  },
  {
    question: 'What happens if someone replies?',
    answer:
      'Our 4-layer reply detection system monitors responses across all threads and automatically stops any scheduled follow-ups. You receive instant notifications via email and SMS, and the AI can even book meetings directly to your calendar if requested.',
  },
  {
    question: 'Can I cancel anytime?',
    answer:
      'Absolutely. There are no contracts or commitments. You can upgrade, downgrade, or cancel your subscription at any time from your account settings. The free plan is available forever with no credit card required.',
  },
  {
    question: 'How accurate is the reply detection?',
    answer:
      'Our reply detection has a 99.7% accuracy rate. It monitors primary inbox, threaded replies, different email aliases, and even catches responses that come from forwarded emails or different domains within the same organization.',
  },
];

export function FAQSection() {
  return (
    <section className="py-24 px-4 bg-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-1/2 left-0 w-72 h-72 bg-violet-100 rounded-full filter blur-3xl opacity-20 -translate-y-1/2"></div>
      <div className="absolute top-1/2 right-0 w-72 h-72 bg-fuchsia-100 rounded-full filter blur-3xl opacity-20 -translate-y-1/2"></div>

      <div className="max-w-3xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-gradient-to-r from-violet-100 to-fuchsia-100 text-violet-700 mb-4">
            <HelpCircle className="w-4 h-4" />
            <span>FAQ</span>
          </div>
          <h2 className="text-4xl md:text-5xl text-center text-gray-900 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-gray-600 text-lg">
            Everything you need to know about our platform
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-violet-100 overflow-hidden"
        >
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border-b border-violet-100 last:border-0"
              >
                <AccordionTrigger className="text-left px-6 py-5 hover:bg-gradient-to-r hover:from-violet-50 hover:to-fuchsia-50 transition-all [&[data-state=open]]:bg-gradient-to-r [&[data-state=open]]:from-violet-50 [&[data-state=open]]:to-fuchsia-50">
                  <span className="text-gray-900">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-5 text-gray-600 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>

        {/* Still have questions CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center mt-12 p-8 rounded-2xl bg-gradient-to-r from-violet-50 to-fuchsia-50 border border-violet-100"
        >
          <p className="text-gray-700 mb-4">
            Still have questions? We're here to help!
          </p>
          <a
            href="#"
            className="inline-block px-6 py-3 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white hover:shadow-lg hover:shadow-violet-500/50 transition-all duration-300"
          >
            Contact Support
          </a>
        </motion.div>
      </div>
    </section>
  );
}
