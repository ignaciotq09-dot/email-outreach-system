import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { FeaturesSection } from './components/FeaturesSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { EmailPreviewCarousel } from './components/EmailPreviewCarousel';
import { SocialProofSection } from './components/SocialProofSection';
import { PricingSection } from './components/PricingSection';
import { FAQSection } from './components/FAQSection';
import { CTASection } from './components/CTASection';
import { Footer } from './components/Footer';
import { Toaster } from './components/ui/sonner';
import { CursorGlow } from './components/CursorGlow';

export default function App() {
  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <CursorGlow />
      <Navigation />
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <EmailPreviewCarousel />
      <SocialProofSection />
      <PricingSection />
      <FAQSection />
      <CTASection />
      <Footer />
      <Toaster />
    </div>
  );
}
